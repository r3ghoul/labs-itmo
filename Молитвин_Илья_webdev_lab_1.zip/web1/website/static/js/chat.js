const messagesDiv = document.getElementById("messages");
const messageInput = document.getElementById("messageInput");
const sendMessageButton = document.getElementById("sendMessage");

const chatName = "your_chat_name"; // Замените на название вашего чата
const token = localStorage.getItem("token"); // Получаем токен из localStorage

const socket = new WebSocket(`ws://localhost/ws/${chatName}`); // Замените localhost на ваш адрес

socket.onmessage = function(event) {
    const message = JSON.parse(event.data);
    const messageElement = document.createElement("div");
    messageElement.textContent = message;
    messagesDiv.appendChild(messageElement);
};

sendMessageButton.onclick = function() {
    const message = messageInput.value;
    if (message) {
        socket.send(JSON.stringify({ message: message, token: token }));
        messageInput.value = ""; // Очищаем поле ввода
    }
};
