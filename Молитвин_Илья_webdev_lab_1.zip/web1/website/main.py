from fastapi import FastAPI, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from datetime import datetime, timedelta
import jwt
import os

from db import SessionLocal, engine, Base
from models import User, ChatRoom
from schemas import UserCreate, UserLogin, UserResponse, Token, ChatRoomCreate, ChatRoomResponse
from crud import create_user, get_user_by_email, create_chat_room, search_chat_rooms, get_user_chat_rooms, delete_chat_room
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

SECRET_KEY = os.getenv("SECRET_KEY", "supersecretkey")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

Base.metadata.create_all(bind=engine)

app = FastAPI()
templates = Jinja2Templates(directory="templates")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_token(request: Request):
    token = request.headers.get("Authorization")
    if token:
        if token.startswith("Bearer "):
            token = token.split(" ")[1]
        return token
    token = request.query_params.get("token")
    if token:
        return token
    raise HTTPException(status_code=401, detail="Token not provided")

def get_current_user(token: str, db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Неверный токен")
        user = get_user_by_email(db, email)
        if user is None:
            raise HTTPException(status_code=401, detail="Пользователь не найден")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Токен истёк")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Неверный токен")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: timedelta = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)):
    to_encode = data.copy()
    expire = datetime.utcnow() + expires_delta
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# Endpoint для выдачи чатового токена (включает email пользователя и название комнаты)
@app.get("/chat/token")
def get_chat_token(room: str, token: str, db: Session = Depends(get_db)):
    user = get_current_user(token, db)
    chat_token = create_access_token(data={"sub": user.email, "chat": room})
    return {"chat_token": chat_token}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# Новый endpoint для отображения дашборда пользователя: создание, список, удаление, поиск чатов
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/chat", response_class=HTMLResponse)
def chat_page(request: Request):
    return templates.TemplateResponse("chat.html", {"request": request})

@app.post("/register", response_model=UserResponse)
def register(user: UserCreate, db: Session = Depends(get_db)):
    if get_user_by_email(db, user.email):
        raise HTTPException(status_code=400, detail="Email уже зарегистрирован")
    hashed_password = hash_password(user.password)
    user_data = User(email=user.email, hashed_password=hashed_password, name=user.name)
    db.add(user_data)
    db.commit()
    db.refresh(user_data)
    return UserResponse(id=user_data.id, email=user_data.email, name=user_data.name, created_at=user_data.created_at)

@app.post("/login", response_model=Token)
def login(user: UserLogin, db: Session = Depends(get_db)):
    db_user = get_user_by_email(db, user.email)
    if not db_user:
        raise HTTPException(status_code=401, detail="Пользователь не найден")
    if not verify_password(user.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Неверные email или пароль")
    access_token = create_access_token(data={"sub": db_user.email})
    return {"access_token": access_token, "token_type": "bearer"}

# Endpoint для создания чат-комнаты (только название комнаты)
@app.post("/chat", response_model=ChatRoomResponse)
def create_chat(chat: ChatRoomCreate, db: Session = Depends(get_db), token: str = Depends(get_token)):
    user = get_current_user(token, db)
    if not chat.name or not chat.name.strip():
        raise HTTPException(status_code=400, detail="Название комнаты не может быть пустым")
    return create_chat_room(db, chat, user.id)

@app.get("/chat/search")
def search_chats(query: str, db: Session = Depends(get_db)):
    if len(query) < 6:
        raise HTTPException(status_code=400, detail="Длина запроса должна быть минимум 6 символов")
    return search_chat_rooms(db, query)

@app.get("/chat/my")
def my_chats(db: Session = Depends(get_db), token: str = Depends(get_token)):
    user = get_current_user(token, db)
    return get_user_chat_rooms(db, user.id)

@app.delete("/chat/{chat_id}")
def delete_chat(chat_id: int, db: Session = Depends(get_db), token: str = Depends(get_token)):
    user = get_current_user(token, db)
    if not delete_chat_room(db, chat_id, user.id):
        raise HTTPException(status_code=403, detail="Нельзя удалить этот чат")
    return {"message": "Чат удалён"}
