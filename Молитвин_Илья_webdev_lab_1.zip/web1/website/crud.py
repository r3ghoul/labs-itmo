from sqlalchemy.orm import Session
from models import User, ChatRoom
from schemas import UserCreate, ChatRoomCreate
from auth import hash_password

# Создание пользователя
def create_user(db: Session, user_data: UserCreate):
    db_user = User(
        email=user_data.email,
        hashed_password=hash_password(user_data.password),
        name=user_data.name
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

# Поиск пользователя по email
def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()

# Создание чата
def create_chat_room(db: Session, chat_data: ChatRoomCreate, owner_id: int):
    db_chat = ChatRoom(
        name=chat_data.name,
        owner_id=owner_id
    )
    db.add(db_chat)
    db.commit()
    db.refresh(db_chat)
    return db_chat

# Поиск чатов по названию
def search_chat_rooms(db: Session, search_query: str):
    return db.query(ChatRoom).filter(ChatRoom.name.ilike(f"%{search_query}%")).all()

# Получение чатов пользователя
def get_user_chat_rooms(db: Session, user_id: int):
    return db.query(ChatRoom).filter(ChatRoom.owner_id == user_id).all()

# Получение чата по ID
def get_chat_room_by_id(db: Session, chat_id: int):
    return db.query(ChatRoom).filter(ChatRoom.id == chat_id).first()

# Удаление чата
def delete_chat_room(db: Session, chat_id: int, user_id: int):
    chat = db.query(ChatRoom).filter(ChatRoom.id == chat_id, ChatRoom.owner_id == user_id).first()
    if chat:
        db.delete(chat)
        db.commit()
        return True
    return False
