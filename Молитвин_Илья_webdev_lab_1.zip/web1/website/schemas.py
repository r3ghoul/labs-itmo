from pydantic import BaseModel, EmailStr
from datetime import datetime

# Схема для регистрации пользователя
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str

# Схема для логина
class UserLogin(BaseModel):
    email: EmailStr
    password: str

# Схема ответа при регистрации (без пароля)
class UserResponse(BaseModel):
    id: int
    email: EmailStr
    name: str
    created_at: datetime

    class Config:
        from_attributes = True

# Схема для JWT-токена
class Token(BaseModel):
    access_token: str
    token_type: str

# Схема для создания чата
class ChatRoomCreate(BaseModel):
    name: str

# Схема ответа с информацией о чате
class ChatRoomResponse(BaseModel):
    id: int
    name: str
    owner_id: int

    class Config:
        from_attributes = True
