from fastapi import FastAPI, WebSocket, HTTPException, status
import jwt
from fastapi import Depends
from fastapi.responses import HTMLResponse
from typing import Dict, List

# Эту переменную можно также импортировать из общих настроек
import os
SECRET_KEY = os.getenv("SECRET_KEY", "supersecretkey")
ALGORITHM = "HS256"

app = FastAPI()

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, room: str, websocket: WebSocket):
        await websocket.accept()
        if room not in self.active_connections:
            self.active_connections[room] = []
        self.active_connections[room].append(websocket)

    def disconnect(self, room: str, websocket: WebSocket):
        if room in self.active_connections:
            self.active_connections[room].remove(websocket)
            if not self.active_connections[room]:
                del self.active_connections[room]

    async def broadcast(self, room: str, message: str):
        if room in self.active_connections:
            for connection in self.active_connections[room]:
                await connection.send_text(message)

manager = ConnectionManager()

# Функция проверки JWT токена для чата
def verify_jwt(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("sub")
        room_in_token = payload.get("chat")
        if email is None or room_in_token is None:
            raise HTTPException(status_code=401, detail="Invalid token payload")
        return email, room_in_token
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# WebSocket эндпоинт для работы с чатами
@app.websocket("/ws/{room}")
async def websocket_endpoint(websocket: WebSocket, room: str, token: str):
    try:
        email, room_in_token = verify_jwt(token)
        if room != room_in_token:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return
    except Exception:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    # Подключение пользователя и уведомление для всех в комнате
    await manager.connect(room, websocket)
    await manager.broadcast(room, f"Пользователь {email} подключился.")

    try:
        while True:
            data = await websocket.receive_text()
            # Здесь можно добавить обработку JSON, если сообщения сложнее
            await manager.broadcast(room, f"{email}: {data}")
    except Exception:
        pass
    finally:
        manager.disconnect(room, websocket)
        await manager.broadcast(room, f"Пользователь {email} отключился.")
